using System;

namespace LibrarySystem
{
	public class clsVariables
	{
		//STRING VARIABLES
		public static string sMSGBOX    = "Library Management System".ToUpper();
		public static string sINSTITUTION;
		public static string sCONTACTNAME;
		public static string sADDRESSS;
		public static string sPHONENUMBER;
		public static string sFAXNUMBER;
		public static string sEMAILADDRESS;
		public static string sWEBSITE;
		public static string sLibrarianID;
		public static string sLibrarianName;
		public static string sUserID;
		public static string sTimeLogin;

	}
}
